#include <stdio.h>
#include <stdlib.h>

// 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2

struct frames{
    int data;
    int index;
} frames[20];

void printArray(int frame_size){
    for(int i = 0; i < frame_size; ++i)
        printf("%d ", frames[i].data);
    printf("\n");
}

int getMin(int frame_size, int n){
    int min = 0;
    for(int i = 0; i < frame_size; ++i){
        if((frames[i].index) < (frames[min].index))
            min = i;
    }
    return min;
}

int lastIndex(int pages, int frame_size, int ref[], int ind){
    
    int res = -1, farthest = ind;
    for(int i = 0; i < frame_size; ++i){
        int j;
        for(j = ind; j < pages; ++j){
            if(frames[i].data == ref[j]){
                if(j > farthest){
                    farthest = j;
                    res = i;
                }
                break;
            }
        }

        if(j == pages)
            return i;
    }

    return (res == -1) ? 0 : res;
}

int checkHit(int frame_size, int n){
    for(int j = 0; j < frame_size; ++j){
        if((frames[j].data) == n){
            return j;
        }
        else if(frames[j].data == -1){
            return -1;
        }
    }
    return -2;
}

void lru(int pages, int frame_size, int ref[]){
    int miss = 0, hit = 0;

    for(int i = 0; i < frame_size; ++i){
        (frames[i].data) = -1;
        (frames[i].index) = -1;
    }

    for(int i = 0; i < pages; ++i){
        int x = checkHit(frame_size, ref[i]);
        
        if(x == -1){    // frames empty
            miss++;
            
            (frames[i].data) = ref[i];
            (frames[i].index) = i;
            
            printf("Miss : ");
            printArray(frame_size);
        }

        else if(x == -2){   // lru condition
            miss++;
            int get_min = getMin(frame_size, ref[i]);
            
            (frames[get_min].data) = ref[i];
            (frames[get_min].index) = i;
            
            printf("Miss : ");
            printArray(frame_size);
        }

        else{   // page hit condition
            hit++;
            
            (frames[x].data) = ref[i];
            (frames[x].index) = i;
            
            printf("Hit : ");
            printArray(frame_size);
        }
    }   

    printf("Misses : %d\n", miss);
    printf("Hits : %d\n", hit);
}

void optimal(int pages, int frame_size, int ref[]){
    int miss = 0, hit = 0;

    for(int i = 0; i < frame_size; ++i){
        (frames[i].data) = -1;
        (frames[i].index) = -1;
    }

    for(int i = 0; i < pages; ++i){
        int x = checkHit(frame_size, ref[i]);
        
        if(x == -1){    // frames empty
            miss++;
            
            (frames[i].data) = ref[i];
            
            printf("Miss : ");
            printArray(frame_size);
        }

        else if(x == -2){   // optimal condition
            miss++;
            
            int predict = lastIndex(pages, frame_size, ref, i+1);
            frames[predict].data = ref[i];

            printf("Miss : ");
            printArray(frame_size);
        }

        else{   // page hit condition
            hit++;
            
            printf("Hit : ");
            printArray(frame_size);
        }
    }   

    printf("Misses : %d\n", miss);
    printf("Hits : %d\n", hit);
}

int main(){
    printf("Enter the number of pages :\n");
    int pages;
    scanf("%d", &pages);

    int ref[pages];
    printf("Enter the reference string array :\n");
    for(int i = 0; i < pages; ++i)
        scanf("%d", &ref[i]);

    printf("Enter the frame size :\n");
    int frame_size;
    scanf("%d", &frame_size);

    printf("Enter your choice :\n");
    printf("1. LRU\n");
    printf("2. Optimal\n");
    printf("3. Exit\n");
    
    int choice;
    scanf("%d", &choice);

    switch(choice){
        case 1:
            lru(pages, frame_size, ref);
            break;

        case 2:
            optimal(pages, frame_size, ref);
            break;

        case 3:
            printf("Exiting now...\n");
            break;

        default:
            printf("Invalid choice\n");
            break;
    }

    return 0;
}