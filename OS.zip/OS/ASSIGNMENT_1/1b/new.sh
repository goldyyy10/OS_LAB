#!/bin/sh

create()
{
    echo "Enter file name : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then 
        echo "Error : File already exists"
    else
        touch $name
        echo "File created successfully"
    fi
}

display()
{
    echo "Enter file name : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then 
        cat $name
    else
        echo "Error : File does not exists"
    fi
}

insert()
{
    echo "Enter file name : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then 
        echo "Enter email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Error : Record already exists"
        else
            echo "Enter data : "
            echo "Enter first name last name and mno : "
            read fname lname mno

            record=`echo $fname $lname $mno`
            cat $record >> $name

            echo "Record Inserted successfully"
        fi
    else
        echo "Error : File does not exists"
    fi
}

update()
{
    echo "Enter file name : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then 
        echo "Enter email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Enter new data : "
            read fname lname mno

            new=`echo $fname $lname $mno`
            old=`cat $name | grep $email`

            echo "Old record is : $old"
            echo "New record is : $new"

            sed -i s/"$old"/"$new"/g $name
            echo "Record updated successfully"
        else
            echo "Error : Record does not exists"
        fi
    else
        echo "Error : File does not exists"
    fi
}

delete()
{
    echo "Enter file name : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then 
        echo "Enter email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            old=`cat $name | grep $email`

            sed -i s/"$old"//g $name
            echo "Record deleted successfully"
        else
            echo "Error : Record does not exists"
        fi
    else
        echo "Error : File does not exists"
    fi
}

while [ true ]
do
    echo "---------MENU---------"
    echo "---------1.Create---------"
    echo "---------2.Display---------"
    echo "---------3.Insert---------"
    echo "---------4.Update---------"
    echo "---------5.Delete---------"
    echo "---------6.Exit---------"
    echo "Enter choice : "
    read choice

    case $choice in
    1) create ;;

    2) display ;;

    3) insert ;;

    4) update ;;

    5) delete ;;

    6) echo "Thank you..."
        break ;;

    *) echo "Invalid choice"
    esac
done
