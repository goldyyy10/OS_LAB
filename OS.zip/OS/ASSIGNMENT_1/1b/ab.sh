#!/bin/sh

create()
{
    echo "Enter name of address book : "
    read ab

    res=`ls | grep $ab | wc -w`

    if [ $res -gt 0 ]
    then
        echo "Error : Address book already exists"
    else
        touch $ab
        echo "Address book created successfully"
    fi
}

display()
{
    echo "Enter name of address book you want to display : "
    read ab

    res=`ls | grep $ab | wc -w`

    if [ $res -gt 0 ]
    then
        cat $ab
    else
        echo "Error : Address book does not exist"
    fi
}

insert()
{
    echo "Enter name of address book you want to insert into : "
    read ab

    res=`ls | grep $ab | wc -w`

    if [ $res -gt 0 ]
    then
        echo email
        read email

        len=`cat $ab | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Error : Email already exists"
        else
            echo "Enter First name, Last name, Mobile no."
            read fname lname mno

            record=`echo $fname $lname $mno`
            echo $record >> $ab
        
            echo "Record inserted successfully"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

update()
{
    echo "Enter name of address book you want to modify : "
    read ab

    res=`ls | grep $ab | wc -w`

    if [ $res -gt 0 ]
    then
        echo email
        read email

        len=`cat $ab | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Enter modified data :"
            echo "Enter First name, Last name, Mobile no."
            read fname lname mno

            new=`echo $fname $lname $mno`
            old=`cat $ab | grep $email`

            echo "Old record : $old"
            echo "New record : $new"

            sed -i s/"$old"/"$new"/g $ab
            echo "Record updated successfully"

        else
            echo "Error : Email does not exists"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

delete()
{
    echo "Enter name of address book you want to modify : "
    read ab

    res=`ls | grep $ab | wc -w`

    if [ $res -gt 0 ]
    then
        echo email
        read email

        len=`cat $ab | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            old=`cat $ab | grep $email`

            sed -i s/"$old"//g $ab
            echo "Record deleted successfully"

        else
            echo "Error : Email does not exists"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

while [ true ]
do
    echo "---------MENU---------"
    echo "1. Create"
    echo "2. Display"
    echo "3. Insert"
    echo "4. Update"
    echo "5. Delete"
    echo "6. Exit"

    echo "Enter choice : "
    read choice

    case $choice in
        1) create ;;

        2) display ;;

        3) insert ;;

        4) update ;;

        5) delete ;;

        6) exit ;;

        *) echo "Invalid choice" ;;
    esac
done

