#!/bin/sh

create()
{
    echo "Enter the name of address book : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then
        echo "Error : Address book already exists"
    else
        touch $name
        echo "Address book created successfully"
    fi
}

display()
{
    echo "Enter the name of address book you want to display : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then
        cat $name
    else
        echo "Error : Address book does not exist"
    fi
}

insert()
{
    echo "Enter the name of address book you want to insert into : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then
        echo "Enter your email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Error : Record already exists"
        else
            echo "Enter First name, Last name, Mobile No : "
            read fname lname mno

            record=`echo $fname $lname $email $mno`
            echo $record >> $name

            echo "Record inserted successfully"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

update()
{
    echo "Enter the name of address book you want to modify : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then
        echo "Enter your email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            echo "Enter new data : "
            echo "Enter your First name, Last name, Mobile No : "
            read fname lname mno

            new=`echo $fname $lname $email $mno`
            old=`cat $name | grep $email`

            echo "Old record is : $old"
            echo "New record is : $new"

            sed -i s/"$old"/"$new"/g $name
            echo "Record modified successfully"

        else
            echo "Error : Record does not exist"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

delete()
{
    echo "Enter the name of address book you want to delete record from : "
    read name

    res=`ls | grep $name | wc -w`

    if [ $res -gt 0 ]
    then
        echo "Enter your email : "
        read email

        len=`cat $name | grep $email | wc -w`

        if [ $len -gt 0 ]
        then 
            old=`cat $name | grep $email`

            sed -i s/"$old"//g $name
            echo "Record deleted successfully"

        else
            echo "Error : Record does not exist"
        fi
    else
        echo "Error : Address book does not exist"
    fi
}

while [ true ]
do
    echo "------------MENU------------"
    echo "1. Create"
    echo "2. Display"
    echo "3. Insert"
    echo "4. Update"
    echo "5. Delete"
    echo "6. Exit"

    echo "Enter your choice : "
    read choice
    
    case $choice in
        1) create ;;

        2) display ;;

        3) insert ;;

        4) update ;;

        5) delete ;;

        6) echo "Thank you"
            break ;;

        *) echo "Invalid choice"

    esac
done