#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

sem_t reader, writer;
int N = 5, data = 0, readCount = 0;

void *Reader(int *index){
    sem_wait(&reader);
    readCount++;

    if(readCount == 1)  
        sem_wait(&writer);
    
    sem_post(&reader);

    printf("Reader %d, read %d\n", (*index) + 1, data);

    sem_wait(&reader);
    readCount--;

    if(readCount == 0)
        sem_post(&writer);
    
    sem_post(&reader);
}

void *Writer(int *index){
    sem_wait(&writer);

    printf("Writer : %d, wrote : %d\n", (*index) + 1, ++data);

    sem_post(&writer);
}

int main(){
    sem_init(&reader, 0, 1);
    sem_init(&writer, 0, 1);

    pthread_t r, w;

    while(1){
        for(int i = 0; i < N; ++i){
            pthread_create(&r, NULL, (void *)Reader, (int *)&i);
            pthread_create(&w, NULL, (void *)Writer, (int *)&i);
        }

        for(int i = 0; i < N; ++i){
            pthread_join(r, NULL);
            pthread_join(w, NULL);
        }
    }

    return 0;
}