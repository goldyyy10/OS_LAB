#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

sem_t reader, writer;
pthread_mutex_t mutex;
int N = 5, data = 0, readCount = 0;

void *Reader(int *index){
    sem_wait(&reader);
    readCount++;

    if(readCount == 1)
        sem_wait(&writer);
        // pthread_mutex_lock(&mutex);
    
    sem_post(&reader);
    printf("Reader %d read data : %d\n", (*index) + 1, data);
    
    sem_wait(&reader);
    readCount--;

    if(readCount == 0)
        sem_post(&writer);
        // pthread_mutex_unlock(&mutex);
    sem_post(&reader);
}

void *Writer(int *index){
    // pthread_mutex_lock(&mutex);
    sem_wait(&writer);

    printf("Writer %d wrote data : %d\n", (*index) + 1, ++data);
    
    // pthread_mutex_unlock(&mutex);
    sem_post(&writer);
}

int main(){
    sem_init(&reader, 0, 1);
    sem_init(&writer, 0, 1);
    pthread_mutex_init(&mutex, NULL);

    pthread_t r, w;

    while(1){
        for(int i = 0; i < N; ++i){
            pthread_create(&r, NULL, (void *)Reader, (int *)&i);
            pthread_create(&w, NULL, (void *)Writer, (int *)&i);
        }

        for(int i = 0; i < N; ++i){
            pthread_join(r, NULL);
            pthread_join(w, NULL);
        }
    }

    return 0;
}