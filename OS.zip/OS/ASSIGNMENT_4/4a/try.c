#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t empty, full;
pthread_mutex_t mutex;
int N = 5, data = 0;
int buffer[5];

void *Producer(int *index){
    sem_wait(&empty);

    pthread_mutex_lock(&mutex);

    buffer[data] = rand() % 10;
    printf("Producer %d produced data : %d\n", (*index) + 1, buffer[data++]);

    printf("-----------------------\n");
    for(int i = 0; i < N; ++i){
        if(i < data)
            printf("| %d ", buffer[i]);
        else
            printf("| - ");
    }
    printf("|\n");
    printf("-----------------------\n");

    pthread_mutex_unlock(&mutex);

    sem_post(&full);
}

void *Consumer(int *index){
    sem_wait(&full);

    pthread_mutex_lock(&mutex);

    printf("Consumer %d consumed data : %d\n", (*index) + 1, buffer[--data]);
    
    printf("-----------------------\n");
    for(int i = 0; i < N; ++i){
        if(i < data)
            printf("| %d ", buffer[i]);
        else
            printf("| - ");
    }
    printf("|\n");
    printf("-----------------------\n");

    pthread_mutex_unlock(&mutex);

    sem_post(&empty);
}

int main(){
    // SEMAPHORE INITIALIZATION
    sem_init(&empty, 0, N);
    sem_init(&full, 0, 0);
    pthread_mutex_init(&mutex, NULL);

    pthread_t p, c;

    while(1){
        for(int i = 0; i < N; ++i){
            // THREAD CREATION
            pthread_create(&p, NULL, (void *)Producer, (int *)&i);
            pthread_create(&c, NULL, (void *)Consumer, (int *)&i);
        }

        for(int i = 0; i < N; ++i){
            pthread_join(p, NULL);
            pthread_join(c, NULL);
        }
    }

    return 0;
}