#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

sem_t empty, full;
pthread_mutex_t mutex;
const int N = 5;
int data = 0;
int buffer[5];

void *Producer(int *index){
    sem_wait(&empty);   

    pthread_mutex_lock(&mutex); // LOCKING THE CRITICAL SECTION

    buffer[data] = rand() % 10;
    printf("\nProducer %d produced data : %d\n", (*index + 1), buffer[data++]);

    printf("---------------------\n");
    for(int i = 0; i < N; ++i){
        if(i < data)
            printf("| %d ", buffer[i]);
        else
            printf("| - ");
    }
    printf("|\n");
    printf("---------------------\n");

    pthread_mutex_unlock(&mutex); // UNLOCKING THE CRITICAL SECTION

    sem_post(&full);
}

void *Consumer(int *index){
    sem_wait(&full);   

    pthread_mutex_lock(&mutex); // LOCKING THE CRITICAL SECTION

    printf("\nConsumer %d consumed data : %d\n", (*index + 1), buffer[--data]);
    
    printf("---------------------\n");
    for(int i = 0; i < N; ++i){
        if(i < data)
            printf("| %d ", buffer[i]);
        else
            printf("| - ");
    }
    printf("|\n");
    printf("---------------------\n");

    pthread_mutex_unlock(&mutex); // UNLOCKING THE CRITICAL SECTION

    sem_post(&empty);
}

int main(){
    pthread_t p, c;

    sem_init(&empty, 0, N);
    sem_init(&full, 0, 0);

    pthread_mutex_init(&mutex, NULL);

    while(1){
        for(int i = 0; i < N; ++i){
            pthread_create(&p, NULL, (void *)Producer, (int *)&i);
            pthread_create(&c, NULL, (void *)Consumer, (int *)&i);
        }

        for(int j = 0; j < N; ++j){
            pthread_join(p, NULL);
            pthread_join(c, NULL);
        }
    }

    return 0;
}