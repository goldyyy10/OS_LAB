#include <stdio.h>

struct process{
    int pid;
    int arrival_time;
    int burst_time;
    int rem_burst_time;
    int completion_time;
    int turn_around_time;
    int waiting_time;
} P[100];

void SJF_P(int processes){
    int completed = 0, time = 0;
    int n = processes;
    int finish[n];

    for(int i = 0; i < n; ++i)
        finish[i] = 0;

    while(completed != n){
        int idx = -1;
        int min = 1000000;

        for(int i = 0; i < n; ++i){
            if(P[i].arrival_time <= time && finish[i] == 0){
                if(P[i].rem_burst_time < min){
                    min = P[i].rem_burst_time;
                    idx = i;
                }

                if(P[i].rem_burst_time == min){
                    if(P[i].arrival_time < P[idx].arrival_time){
                        min = P[i].rem_burst_time;
                        idx = i;
                    }
                }
            }
        }

        if(idx != -1){
            P[idx].rem_burst_time -= 1;
            time++;

            if(P[idx].rem_burst_time == 0){
                P[idx].completion_time = time;
                P[idx].turn_around_time = P[idx].completion_time - P[idx].arrival_time;
                P[idx].waiting_time = P[idx].turn_around_time - P[idx].burst_time;
                
                finish[idx] = 1;
                completed++;
            }
        }else{
            time++;
        }
    }

    int tot_turn_around_time = 0, tot_waiting_time = 0;

    for(int i = 0; i < n; ++i){
        tot_turn_around_time += P[i].turn_around_time;
        tot_waiting_time += P[i].waiting_time;
    }

    printf("P\tAT\tBT\tCT\tTAT\tWT\n");

    for(int i = 0; i < processes; ++i){
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", i, P[i].arrival_time, P[i].burst_time, P[i].completion_time, P[i].turn_around_time, P[i].waiting_time);
    }


    printf("Average TAT is : %f\n", (float)tot_turn_around_time / (float)n);
    printf("Average WT is : %f\n", (float)tot_waiting_time / (float)n);
}

// void roundRobin(){

// }

int main(){
    printf("Enter the number of processes :\n");
    int processes;
    scanf("%d", &processes);

    printf("Enter arrival time of each process :\n");
    for(int i = 0; i < processes; ++i){
        printf("Enter arrival time of process P%d : ", i);
        int at;
        scanf("%d", &P[i].arrival_time);
    }

    printf("Enter burst time of each process :\n");
    for(int i = 0; i < processes; ++i){
        printf("Enter burst time of process P%d : ", i);
        int at;
        scanf("%d", &P[i].burst_time);
        P[i].rem_burst_time = P[i].burst_time;
    }

    // printf("Enter your choice :\n");
    // printf("1. SJF\n");
    // printf("2. Round Robin\n");
    // printf("3. Exit\n");

    // int choice;
    // scanf("%d", &choice);

    // switch(choice){
    //     case 1:
            SJF_P(processes);
            // break;

    //     case 2:
    //         roundRobin(processes);
    //         break;

    //     case 3:
    //         printf("Exiting ....\n");
    //         break;

    //     default:
    //         printf("Invalid choice\n");
    //         break;;
    // }

    return 0;
}