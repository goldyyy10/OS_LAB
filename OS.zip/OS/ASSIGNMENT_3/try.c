#include <stdio.h>

struct process{
    int pid;
    int at;
    int bt;
    int ct;
    int tat;
    int wt;
    int rbt;
} p[100];

void SJF(int n){
    int completed = 0, time = 0;
    int finish[n];

    for(int i = 0; i < n; ++i)
        finish[i] = 0;

    while(completed != n){
        int index = -1, min = 100000;
        for(int i = 0; i < n; ++i){
            if(p[i].at <= time && finish[i] == 0){
                if(p[i].rbt < min){
                    min = p[i].rbt;
                    index = i;
                }

                if(p[i].rbt == min){
                    if(p[i].at < p[index].at){
                        min = p[i].rbt;
                        index = i;
                    }
                }
            }
        }

        if(index != -1){
            p[index].rbt -= 1;
            time++;

            if(p[index].rbt == 0){
                p[index].ct = time;
                p[index].tat = p[index].ct - p[index].at;
                p[index].wt = p[index].tat - p[index].bt;

                finish[index] = 1;
                completed++;
            }
        }
        else{
            time++;
        }
    }

    int ttat = 0, twt = 0;
    for(int i = 0; i < n; ++i){
        ttat += p[i].tat;
        twt += p[i].wt;
    }

    printf("P\tAT\tBT\tCT\tTAT\tWT\n");

    for(int i = 0; i < n; ++i){
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", i, p[i].at, p[i].bt, p[i].ct, p[i].tat, p[i].wt);
    }
    printf("\n");


    printf("Average TAT is : %f\n", (float)ttat / n);
    printf("Average WT is : %f\n", (float)twt / n);
}

int main(){
    printf("Enter the number of processes :\n");
    int n;
    scanf("%d", &n);

    for(int i = 0; i < n; ++i){
        printf("Enter arrival time for P%d : ", i);
        int at;
        scanf("%d", &p[i].at);

        printf("Enter burst time for P%d : ", i);
        int bt;
        scanf("%d", &p[i].bt);
        p[i].rbt = p[i].bt;
    }

    SJF(n);

    return 0;
}