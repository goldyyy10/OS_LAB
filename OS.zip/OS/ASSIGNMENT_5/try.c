#include <stdio.h>
#include <stdbool.h>

int Available[10];
int Max_Need[10][10];
int Allocated[10][10];
int Need[10][10];

void printAvailable(int R){
    printf("-------------------------------\n");
    printf("Available Matrix :\n");
    printf("   A B C\n");
    printf("   ");
    for(int i = 0; i < R; ++i){
        printf("%d ", Available[i]);
    }
    printf("\n");
}

void printMax_Need(int P, int R){
    printf("-------------------------------\n");
    printf("Maximum Need Matrix :\n");
    printf("   A B C\n");
    for(int i = 0; i < P; ++i){
        printf("P%d ", i);
        for(int j = 0; j < R; ++j){
            printf("%d ", Max_Need[i][j]);
        }
        printf("\n");
    }
}

void printAllocated(int P, int R){
    printf("-------------------------------\n");
    printf("Allocated Matrix :\n");
    printf("   A B C\n");
    for(int i = 0; i < P; ++i){
        printf("P%d ", i);
        for(int j = 0; j < R; ++j){
            printf("%d ", Allocated[i][j]);
        }
        printf("\n");
    }
}

void printNeed(int P, int R){
    printf("-------------------------------\n");
    printf("Need Matrix :\n");
    printf("   A B C\n");
    for(int i = 0; i < P; ++i){
        printf("P%d ", i);
        for(int j = 0; j < R; ++j){
            printf("%d ", Need[i][j]);
        }
        printf("\n");
    }
}

void max_need(int P, int R){
    for(int i = 0; i < P; ++i){
        // printf("Enter max_need resouces :\n");
        for(int j = 0; j < R; ++j){
            scanf("%d", &Max_Need[i][j]);
        }
    }
}

void allocated(int P, int R){
    for(int i = 0; i < P; ++i){
        for(int j = 0; j < R; ++j){
            scanf("%d", &Allocated[i][j]);
        }
    }
}

void need_matrix(int P, int R){
    for(int i = 0; i < P; ++i){
        for(int j = 0; j < R; ++j){
            Need[i][j] = Max_Need[i][j] - Allocated[i][j];
        }
    }
}

void available(int P, int R){
    for(int i = 0; i < P; ++i){
        for(int j = 0; j < R; ++j){
            Available[j] -= Allocated[i][j];
        }
    }
}

void bankers(int P, int R){
    int x = 0;
    int safe[P], finish[P];

    for(int i = 0; i < P; ++i)
        finish[i] = 0;

    for(int k = 0; k < P; ++k){
        for(int i = 0; i < P; ++i){
            if(finish[i] == 0){
                int flag = 0;

                for(int j = 0; j < R; ++j){
                    if(Need[i][j] > Available[j]){
                        flag = 1;
                        break;
                    }
                }

                if(flag == 0){
                    safe[x++] = i;
                    for(int y = 0; y < R; ++y)
                        Available[y] += Allocated[i][y];
                    finish[i] = 1;
                }
            }
        }
    }

    int f1 = 0;
    for(int i = 0; i < P; ++i){
        if(finish[i] == 0){
            f1 = 1;
            break;
        }
    }

    if(f1 == 0){
        printf("-------------------------------\n");
        printf("System is in safe state\n Safe sequence is :\n");
        for(int i = 0; i < P - 1; ++i){
            printf(" P%d => ", safe[i]);
        }
        printf(" P%d\n", safe[P - 1]);
        printf("-------------------------------\n");
    }
    else{
        printf("-------------------------------\n");
        printf("System is not in safe state\n");
        printf("-------------------------------\n");
    }
}

int main(){
    printf("Enter the number of processes :\n");
    int processes;
    scanf("%d", &processes);

    printf("Enter the number of resources :\n");
    int resources;
    scanf("%d", &resources);

    char x = 'A';
    for(int i = 0; i < resources; ++i){
        printf("Enter total available instances of resource %c : ", x++);
        int n;
        scanf("%d", &n);
        Available[i] = n;
    }

    printf("Enter the Max_Need matrix :\n");
    max_need(processes, resources);

    printf("Enter the Allocated matrix :\n");
    allocated(processes, resources);

    printMax_Need(processes, resources);
    printAllocated(processes, resources);

    available(processes, resources);
    printAvailable(resources);

    // printf("Need matrix is :\n");
    need_matrix(processes, resources);
    printNeed(processes, resources);

    bankers(processes, resources);

    return 0;
}

/*
7 5 3
3 2 2
9 0 2
2 2 2
4 3 3

0 1 0 
2 0 0
3 0 2
2 1 1
0 0 2
*/