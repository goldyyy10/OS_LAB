#include <stdio.h>
#include <stdlib.h>

int bSearch(int arr[], int low, int high, int x){
    if(high >= low){
        int mid = (low + high) / 2;

        if(arr[mid] == x)
            return mid;
        
        if(arr[mid] > x)
            return bSearch(arr, low, mid - 1, x);
        
        else
            return bSearch(arr, mid + 1, high, x);
    }

    return -1;
}

int main(int argc, char *argv[]){
    int size = argc - 1;
    int arr[size];

    for(int i = 1; i <= size; ++i){
        arr[i - 1] = atoi(argv[i]);
    }

    // int x;

    // while(1){
    //     printf("Enter the element you want to search :\n");
    //     scanf("%d", &x);

    //     if(x == -1){
    //         printf("Exiting the application...\n");
    //         break;
    //     }

    //     int index = bSearch(arr, 0, size - 1, x);

    //     if(index == -1){
    //         printf("Element not present in array\n");
    //     }
    //     else{
    //         printf("Element found at index : %d\n", index);
    //     }
    // }

    for(int i = size - 1; i >= 0; --i){
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}