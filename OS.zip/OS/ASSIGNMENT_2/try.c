#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>

void printArray(int arr[], int n){
    for(int i = 0; i < n; ++i)
        printf("%d ", arr[i]);
    printf("\n");
}

void swap(int *a, int *b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

void bubbleSort(int arr[], int n){
    for(int i = 0; i < n; ++i){
        for(int j = 0; j < n - 1; ++j){
            if(arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
        }
    }
}

int partition(int arr[], int low, int high){
    int pivot = arr[low];
    int i = low, j = high;

    while(i < j){
        do{
            i++;
        }   while(arr[i] <= pivot);

        do{
            j--;
        }   while(arr[j] > pivot);

        if(i < j){
            swap(&arr[i], &arr[j]);
        }
    }

    swap(&arr[low], &arr[j]);

    return j;
}

void quickSort(int arr[], int low, int high){
    if(low < high){
        int j = partition(arr, low, high);

        quickSort(arr, low, j - 1);
        quickSort(arr, j + 1, high);
    }
}

int main(){
    pid_t pid;

    printf("This is the main process with with process id : %d\n", getpid());

    printf("Enter the size of array :\n");
    int size;
    scanf("%d", &size);

    int arr[size];

    printf("Enter array elements :\n");
    for(int i = 0; i < size; ++i)
        scanf("%d", &arr[i]);
    

    printf("Array before sorting :\n");
    printArray(arr, size);

    // bubbleSort(arr, size);
    quickSort(arr, 0, size);

    printf("Array after sorting :\n");
    printArray(arr, size);

    printf("FORKING THE PROCESS\n");

    pid = fork();

    if(pid < 0){
        printf("CHILD WASN'T BORN\n");
    }
    else if(pid == 0){
        printf("\n--------------CHILD PROCESS--------------\n");

        printf("This is child with process id : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());

        char strArr[size][1000];

        for(int i = 0; i < size; ++i){
            sprintf(strArr[i], "%d", arr[i]);   // INTEGER TO STRING
        }

        char *buffer[size + 2];

        buffer[0] = "./sea.out";

        for(int i = 0; i < size; ++i){
            buffer[i + 1] = strArr[i];
        }

        buffer[size + 1] = NULL;

        execvp(buffer[0], buffer);
        // printf("CONTROL GOING TO NEW FILE\n");

        printf("CHILD PROCESS COMPLETED\n");
    }
    else{
        wait(NULL);
        printf("\n--------------PARENT PROCESS--------------\n");

        printf("This is parent with process id : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);

        printf("PARENT PROCESS COMPLETED\n"); 
    }

    return 0;
}