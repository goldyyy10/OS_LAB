#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    pid_t pid;

    pid = fork();

    if(pid < 0) // ERROR
        printf("Error occured\n");
    else if(pid == 0){      // CHILD PROCESS
        printf("Child process id is : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());
        
        pid_t p = fork();

        if(p == 0){
            printf("My pid is : %d\n", getpid());
            printf("My parent's pid is : %d\n", getppid());
        }
        else{
            printf("Parent here with pid : %d\n", getpid());
            printf("My child's pid is : %d\n", p);
        }
    }   
    else{   // PARENT PROCESS
        printf("Parent process id is : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);
    }
        

    return 0;
}
