#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

void printArray(int arr[], int n){
    for(int i = 0; i < n; ++i)
        printf("%d ", arr[i]);
    printf("\n");
}

void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

void bubblesort(int arr[], int n){
    for(int i = 0; i < n; ++i){
        for(int j = 0; j < n - 1; ++j){
            if(arr[j] > arr[j + 1]){
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

int partition(int arr[], int low, int high)
{
    int pivot = arr[low];
    int i = low, j = high;

    while(i < j){
        do{
            i++;
        }   while(arr[i] <= pivot);

        do{
            j--;
        }   while(arr[j] > pivot);

        if(i < j)
            swap(&arr[i], &arr[j]);
    }

    swap(&arr[low], &arr[j]);
    
    return j;
}

void quickSort(int arr[], int low, int high)
{
    if (low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void sorting(){
    printf("Enter the size of array :\n");
    int size;
    scanf("%d", &size);
    
    printf("Enter the elements of array : \n");
    
    int a[size];
    for(int i = 0; i < size; ++i)
        scanf("%d", &a[i]);

    // CREATING CHILD PROCESS
    pid_t pid;
    pid = fork();

    if(pid == 0){
        printf("\n--------------CHILD PROCESS--------------\n");
        printf("This is child with process id : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());

        printf("Array before sorting :\n");
        printArray(a, size);

        bubblesort(a, size);
        
        printf("Array after sorting :\n");
        printArray(a, size);
        
        exit(0);
    }
    else if(pid > 0){
        wait(NULL);

        printf("\n--------------PARENT PROCESS--------------\n");
        printf("This is parent with process id : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);

        printf("Array before sorting :\n");
        printArray(a, size);

        quickSort(a, 0, size);
        
        printf("Array after sorting :\n");
        printArray(a, size);
    }
    else{
        printf("Child process creation unsuccessfull\n");
    }
}

void orphan(){
    printf("\n--------------ORPHAN PROCESS--------------\n");
    char buffer[25];

    pid_t pid;

    pid = fork();

    if(pid < 0){
        printf("Child wasn't born\n");
    }
    else if(pid == 0){
        sleep(5);
        
        printf("\nCHILD IS NOW IN ORPHAN STATE\n");

        printf("This is child with process id : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());

        snprintf(buffer, 25, "ps -elf | grep %d", getpid());
        system(buffer);
    }
    else{
        printf("This is parent with process id : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);

        printf("PARENT EXECUTED SUCCESSFULLY.\n");
    }
}

void zombie(){
    printf("\n--------------ZOMBIE PROCESS--------------\n");
    char buffer[25];

    pid_t pid;

    pid = fork();

    if(pid < 0){
        printf("Child wasn't born\n");
    }
    else if(pid == 0){
        printf("This is child with process id : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());

        snprintf(buffer, 25, "ps -elf | grep %d", getpid());
        system(buffer);

        printf("CHILD EXECUTED SUCCESSFULLY.\n");
    }
    else{
        sleep(5);
        printf("\nCHILD IS NOW IN ZOMBIE STATE\n");

        printf("This is parent with process id : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);

        snprintf(buffer, 25, "ps -elf | grep %d", getpid());
        system(buffer);
    }
}

int main(){

    printf("\nChoose from the following options : \n");
    
    printf("1. Sorting\n");
    printf("2. Orphan\n");
    printf("3. Zombie\n");
    printf("4. Exit\n");

    printf("Enter your choice : \n");
    int choice;
    scanf("%d", &choice);

    switch (choice)
    {
        case 1:
            sorting();
            break;

        case 2:
            orphan();
            break;

        case 3:
            zombie();
            break;

        case 4:
            printf("Exiting the application...\n");
            choice = 0;
            break;
        
        default:
            break;
    }

    return 0;
}