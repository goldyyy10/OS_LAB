#include <stdio.h>
#include <stdlib.h>

int bSearch(int arr[], int low, int high, int x){
    if(high >= low){
        int mid = (low + high) / 2;

        if(arr[mid] == x)
            return mid;
        
        if(arr[mid] > x)
            return bSearch(arr, low, mid - 1, x);
        
        else
            return bSearch(arr, mid + 1, high, x);
    }

    return -1;
}

int main(int argc, char *argv[]){
    printf("argc is %d\n", argc);

    for(int i = 0; i < argc; ++i){
        printf("%s ", argv[i]);
    }
    printf("\n");

    int n = argc - 1;
    int arr[n];

    for(int i = 1; i <= n; ++i){
        arr[i - 1] = atoi(argv[i]);
    }

    int x;

    while(1){
        printf("Enter the element you want to search :\n");
        scanf("%d", &x);

        if(x == -1){
            printf("Exiting from the application...\n");
            break;
        }

        int res = bSearch(arr, 0, n - 1, x);

        if(res == -1){
            printf("Element not present in array\n");
        }
        else{
            printf("Element found at index : %d\n", res);
        }
    }

    return 0;
}
