#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>

void printArray(int arr[], int n){
    for(int i = 0; i < n; ++i)
        printf("%d ", arr[i]);
    printf("\n");
}

void swap(int *a, int *b){
    int temp = *a;
    *a = *b;
    *b =temp;
}

int partition(int arr[], int low, int high)
{
    int pivot = arr[low];
    int i = low, j = high;

    while(i < j){
        do{
            i++;
        }   while(arr[i] <= pivot);

        do{
            j--;
        }   while(arr[j] > pivot);

        if(i < j)
            swap(&arr[i], &arr[j]);
    }

    swap(&arr[low], &arr[j]);
    
    return j;
}

void quickSort(int arr[], int low, int high)
{
    if (low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void bubblesort(int arr[], int n){
    for(int i = 0; i < n; ++i){
        for(int j = 0; j < n - 1; ++j){
            if(arr[j] > arr[j + 1]){
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

int main(){
    pid_t pid;

    printf("This is the parent process with process id : %d\n", getpid());

    printf("Enter the size of array :\n");
    int size;
    scanf("%d", &size); 

    int a[size];

    printf("Enter the array elements :\n");
    for(int i = 0; i < size; ++i)
        scanf("%d", &a[i]);

    printf("Array before sorting :\n");
    printArray(a, size);

    quickSort(a, 0, size);
    // bubblesort(a, size);

    printf("Array after sorting :\n");
    printArray(a, size);

    pid = fork();

    if(pid < 0){
        printf("Child creation unsuccessful\n");
    }
    else if(pid == 0){
        printf("\n--------------CHILD PROCESS--------------\n");

        printf("This is child process with process id : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());

        char strArr[size][1000];    

        for(int i = 0; i < size; ++i){
            sprintf(strArr[i], "%d", a[i]);
        }

        char *args[size + 2];
        args[0] = "./search.out";
        
        for(int i = 0; i < size; ++i){
            args[i + 1] = strArr[i];
        }

        args[size + 1] = NULL;
        execvp(args[0], args);

        printf("\nCHILD EXECUTED SUCCESSFULLY\n");
    }
    else{
        wait(NULL);
        printf("\n--------------PARENT PROCESS--------------\n");

        printf("This is parent with process id : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);

        printf("\nPARENT EXECUTED SUCCESSFULLY\n");
    }


    return 0;
}