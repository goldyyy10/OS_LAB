#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
    pid_t pid;

    pid = fork();

    if(pid < 0) // ERROR
        printf("Error occured\n");
    else if(pid == 0){      // CHILD PROCESS
        printf("Child process id is : %d\n", getpid());
        printf("My parent's process id is : %d\n", getppid());
    }   
    else{   // PARENT PROCESS
        wait(NULL);
        printf("Parent process id is : %d\n", getpid());
        printf("My child's process id is : %d\n", pid);
    }
        

    return 0;
}
