#!/bin/bash

echo "$1 is the first argument"
echo "$2 is the second argument"
echo "$3 is the third argument"
