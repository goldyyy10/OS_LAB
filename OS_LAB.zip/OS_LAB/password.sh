#!/bin/bash

echo "Enter username :"
read username

echo "Enter password :"
read -s password
echo
