#!/bin/bash

echo "Enter a number :"
read number

sum=0
digit=0

for (( i = $number; i > 0; i=i/10 ))
do
	digit=`expr $number % 10`
	sum=`expr $sum + $digit`
	number=`expr $number / 10`
done

echo $sum
