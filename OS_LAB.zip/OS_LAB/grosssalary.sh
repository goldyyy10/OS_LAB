#!/bin/bash

dearness=0.0
rent=0.0
gross=0.0

echo "Enter basic salary :"
read basic

dearness=`expr 0.4\*$basic`
rent=`expr 0.2\*$basic`

gross=`expr $dearness + $rent + $basic`

echo "Gross salary is :" $gross
