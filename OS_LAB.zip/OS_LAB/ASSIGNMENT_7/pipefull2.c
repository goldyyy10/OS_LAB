
// C program to implement one side of FIFO 
// This side reads first, then reads 
#include <stdio.h> 
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
  
int main() 
{ 
    int fd1; 
  
    // FIFO file path 
    char * myfifo1 = "/tmp/myfifo1";
    char * myfifo2 = "/tmp/myfifo2";  
  
    // Creating the named file(FIFO) 
    // mkfifo(<pathname>,<permission>) 
    mkfifo(myfifo1, 0666); 
    mkfifo(myfifo2, 0666);
  
    char str1[1000], str2[1000]; 
    while (1) 
    { 
        // First open in read only and read 
        fd1 = open(myfifo1,O_RDONLY); 
        read(fd1, str1, 1000); 

        int i = 0, cnt = 0;
  
        while(str1[i] != '\0'){
            if(str1[i] == ' '){
                cnt++;
            }
            i++;
        }
  
        // Print the read string and close 
        // printf("User1: %s\n", str1);
        // printf("Word Count: %d\n", cnt+1); 
        close(fd1); 

        int x = cnt+1;
        int length = snprintf( NULL, 0, "%d", x );
        char* s = malloc( length + 1 );
        snprintf( s, length + 1, "%d", x );
        // printf("int to string : %s\n", s);vc

        int c = i-1;
        int clength = snprintf( NULL, 0, "%d", c );
        char* ch = malloc( clength + 1 );
        snprintf( ch, clength + 1, "%d", c );
        // Now open in write mode and write 
        // string taken from user. 
        fd1 = open(myfifo2,O_WRONLY); 
        // fgets(s, 1000, stdin); 
        write(fd1, s, strlen(s)+1); 
        write(fd1, ch, strlen(ch)+1); 

        close(fd1); 

        free(s);
    } 
    return 0; 
} 

