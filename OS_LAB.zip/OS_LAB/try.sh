#!/bin/bash
echo "hello world"
cat demo.txt
ls -l demo.txt
