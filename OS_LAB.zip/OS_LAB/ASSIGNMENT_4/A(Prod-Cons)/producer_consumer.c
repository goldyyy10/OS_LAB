#include <stdio.h>
#include <semaphore.h>
#include <unistd.h>
#include <pthread.h>
#define N 5

int arr[N];    
int i = 1;   
sem_t full, empty;      
pthread_mutex_t lock;   

void *Producer(int *id)     
{
    sem_wait(&empty);      
    pthread_mutex_lock(&lock);

    printf("Producer %d produced item %d\n", *(id), arr[++i]);

    printf("---------------------\n");
    for(int j = 1; j <= N; ++j){
        if(j <= i)
            printf("| %d ", arr[j]);
        else 
            printf("| - ");
    }
    printf("|\n");
    printf("---------------------\n");
    
    pthread_mutex_unlock(&lock);
    sem_post(&full);        
}

void *Consumer(int *id)     
{
    sem_wait(&full);        
    pthread_mutex_lock(&lock);
    
    printf("Consumer %d consumed item %d\n", *(id), arr[i--]);

    printf("---------------------\n");
    for(int j = 1; j <= N; ++j){
        if(j <= i)
            printf("| %d ", arr[j]);
        else 
            printf("| - ");
    }
    printf("|\n");
    printf("---------------------\n");

    if(i == 0){
        i = 1;
    }

    pthread_mutex_unlock(&lock);
    sem_post(&empty);      
}

int main()      
{
	sem_init(&empty, 0, N);
	sem_init(&full, 0, 0);
	pthread_mutex_init(&lock, NULL);

	int n = 5;

	pthread_t p[n], c[n];

    for(int k = 0; k < N; ++k){
        arr[k] = k+1;
    }

    while(1){
        for (int k = 1; k <= n; ++k)
        {
            pthread_create(&p[k - 1], NULL, (void *)Producer, (int *)&k);
            pthread_create(&c[k - 1], NULL, (void *)Consumer, (int *)&k);
        }
       
        for (int k = 1; k <= n; ++k)
        {
            pthread_join(p[k - 1], NULL);
            pthread_join(c[k - 1], NULL);
        }
    }

	return 0;
}
