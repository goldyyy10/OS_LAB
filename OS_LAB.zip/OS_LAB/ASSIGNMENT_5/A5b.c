#include <stdio.h>
#include <stdbool.h>

int main()
{
    int P, R;
    printf("Enter the number of processes: ");
    scanf("%d", &P);
    printf("Enter the number of resources: ");
    scanf("%d", &R);

    int Available[R], A1[R], A2[R];
    int Max[P][R];
    int Allocation[P][R], Al1[P][R];
    int Need[P][R], N1[P][R];

    printf("Enter the number of maximum resources required\n");
    for (int i = 0; i < P; i++)
    {
        printf("By P%d\n", i);
        for (int j = 0; j < R; j++)
        {
            int x;
            printf("R%d: ", j);
            scanf("%d", &x);
            Max[i][j] = x;
        }
        printf("\n");
    }

    printf("Enter the number of resources allocated\n");
    for (int i = 0; i < P; i++)
    {
        printf("To P%d\n", i);
        for (int j = 0; j < R; j++)
        {
            int x;
            printf("R%d: ", j);
            scanf("%d", &x);
            Allocation[i][j] = x;
            Al1[i][j] = x;
        }
        printf("\n");
    }

    printf("Enter the number of resources available\n");
    for (int j = 0; j < R; j++)
    {
        int x;
        printf("R%d: ", j);
        scanf("%d", &x);
        Available[j] = x;
        A1[j] = x;
        A2[j] = x;
    }

    printf("Need matrix:\n");
    for (int i = 0; i < P; i++)
    {
        printf("P%d: ", i);
        for (int j = 0; j < R; j++)
        {
            Need[i][j] = Max[i][j] - Allocation[i][j];
            N1[i][j] = Need[i][j];
            printf("%d ", Need[i][j]);
        }
        printf("\n");
    }

    bool Finish[R];
    int c = 0;
    for (int k = 0; k < R; k++)
    {
        Finish[k] = false;
    }

    int f = 1, g = 1, a = 0;
    int ans[P];
    while (g)
    {
        g = 0;
        for (int i = 0; i < P; i++)
        {
            f = 0;
            if (Finish[i] == false)
            {
                for (int j = 0; j < R; j++)
                {
                    if (Need[i][j] > Available[j])
                        f = 1;
                }
                if (f == 0)
                {
                    g = 1;
                    for (int k = 0; k < R; k++)
                    {
                        Available[k] += Allocation[i][k];
                    }
                    Finish[i] = true;
                    ans[a++] = i;
                }
            }
        }
    }

    for (int k = 0; k < P; k++)
    {
        if (Finish[k] == false)
        {
            printf("Unsafe state\n");
            c = 1;
            break;
        }
    }
    if (c == 0)
    {
        printf("Safe Sequence:\n");
        for (int i = 0; i < P; i++)
        {
            printf("->P%d", ans[i]);
        }
        printf("\n");
    }

    while (1)
    {
        int Request[R];
        int y, d1 = 0;

        for (int j = 0; j < R; j++)
        {
            A1[j] = A2[j];
        }

        printf("Enter the name of process: ");
        scanf("%d", &y);
        printf("Enter the resources requested by P%d: \n", y);
        for (int j = 0; j < R; j++)
        {
            int x;
            printf("R%d: ", j);
            scanf("%d", &x);
            Request[j] = x;

            if (N1[y][j] < Request[j])
            {
                printf("Error: Resources requested are greater than maximum resources\n");
                d1 = 1;
                break;
            }
            if (A1[j] < Request[j])
            {
                printf("Resources requested are greater than available resources\n");
                d1 = 1;
                break;
            }
        }

        if (d1 == 0)
        {
            bool F1[R];
            int c1 = 0;

            for (int j = 0; j < R; j++)
            {
                A1[j] -= Request[j];
                N1[y][j] -= Request[j];
                F1[j] = false;
            }

            int f1 = 1, g1 = 1, a1 = 0;
            int ans1[P];
            while (g1)
            {
                g1 = 0;
                for (int i = 0; i < P; i++)
                {
                    f1 = 0;
                    if (F1[i] == false)
                    {
                        for (int j = 0; j < R; j++)
                        {
                            if (N1[i][j] > A1[j])
                                f1 = 1;
                        }
                        if (f1 == 0)
                        {
                            g1 = 1;
                            for (int k = 0; k < R; k++)
                            {
                                A1[k] += Al1[i][k];
                            }
                            F1[i] = true;
                            ans1[a1++] = i;
                        }
                    }
                }
            }

            for (int k = 0; k < P; k++)
            {
                if (F1[k] == false)
                {
                    printf("Unsafe state\n");
                    printf("Resources cannot be allocated\n");
                    for (int j = 0; j < R; j++)
                    {
                        A1[j] = A2[j];
                        N1[y][j] += Request[j];
                    }
                    c1 = 1;
                    break;
                }
            }
            if (c1 == 0)
            {
                for (int j = 0; j < R; j++)
                {
                    A2[j] -= Request[j];
                    Al1[y][j] += Request[j];
                }
                printf("Resources allocated\n");
                printf("Safe Sequence:\n");
                for (int i = 0; i < P; i++)
                {
                    printf("->P%d", ans1[i]);
                }
            }

            printf("\nNeed matrix:\n");
            for (int i = 0; i < P; i++)
            {
                printf("P%d: ", i);
                for (int j = 0; j < R; j++)
                {
                    printf("%d ", N1[i][j]);
                }
                printf("\n");
            }
        }
    }

    return 0;
}