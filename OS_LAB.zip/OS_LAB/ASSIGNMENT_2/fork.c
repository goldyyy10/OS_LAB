#include <stdio.h>
#include <unistd.h>

int main()
{
	/*
	printf("Before fork : \n");
	
	printf("Process ID of child process is : %d\n", (int)getpid());
	printf("Process ID of parent process is : %d\n", (int)getppid());
	
	pid_t p;
	p = fork();
	
	printf("After fork : \n");
	
	printf("Process ID of child process is : %d\n", (int)getpid());
	printf("Process ID of parent process is : %d\n", (int)getppid());
	*/
	
	pid_t p;
	p = fork();
	
	if (p == 0)
        printf("Hello from Child!\n");
  
    // parent process because return value non-zero.
    else
        printf("Hello from Parent!\n");
	
	return 0;
}
