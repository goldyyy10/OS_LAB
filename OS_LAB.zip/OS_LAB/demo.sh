#!/bin/bash
echo "Enter your name :"
read Fname Sname

echo "Enter your division : "
read div

echo "Enter your address :"
read address

echo "First name is :" $Fname
echo "Last name is :" $Sname
echo "Division is :" $div
echo "Address is :" $address
