#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>

const int N = 5;
int cnt = 0, data = 10;
sem_t reader, writer;
pthread_mutex_t lock;

// void Reader(int *arg){
//     sem_wait(&reader);
//     cnt++;

//     if(cnt == 1)
//         sem_wait(&writer);

//     sem_post(&reader);
//     printf("Reader %d read data : %d\n", *arg, data);

//     sem_wait(&reader);
//     cnt--;

//     if(cnt == 0)
//         sem_post(&writer);

//     sem_post(&reader);
// }

// void Writer(int *arg){
//     sem_wait(&writer);

//     printf("Writer %d wrote data : %d\n", *arg, ++data);

//     sem_post(&writer);
// }

void Reader(int *arg){
    sem_wait(&reader);
    cnt++;

    if(cnt == 1)
        pthread_mutex_lock(&lock);

    sem_post(&reader);
    printf("Reader %d read data : %d\n", *arg, data);

    sem_wait(&reader);
    cnt--;

    if(cnt == 0)
        pthread_mutex_unlock(&lock);

    sem_post(&reader);
}

void Writer(int *arg){
    pthread_mutex_lock(&lock);

    printf("Writer %d wrote data : %d\n", *arg, ++data);

    pthread_mutex_unlock(&lock);
}

int main(){
    pthread_t r[N+1], w[N+1];

    sem_init(&reader, 0, 1);
    sem_init(&writer, 0, 1);
    pthread_mutex_init(&lock, NULL);

    int i;
    
    while(1){
        for(i = 1; i <= N; ++i){
            pthread_create(&r[i], NULL, (void *)Reader, (int *)&i);
            pthread_create(&w[i], NULL, (void *)Writer, (int *)&i);
        }

        for(i = 1; i <= N; ++i){
            pthread_join(r[i], NULL);
            pthread_join(w[i], NULL);
        }
    }

    return 0;
}