#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>

const int N = 5;
int arr[N+1];
sem_t empty, full;
pthread_mutex_t lock;

void Producer(int *arg){
    sem_wait(&empty);
    pthread_mutex_lock(&lock);

    pthread_mutex_unlock(&lock);
    sem_post(&full);
}

void Consumer(int *arg){
    sem_wait(&full);
    pthread_mutex_lock(&lock);

    pthread_mutex_unlock(&lock);
    sem_post(&empty);
}

int main(){
    sem_init(&empty, 0, N);
    sem_init(&full, 0, 0);
    pthread_mutex_init(&lock, NULL);

    int i;

    pthread_t p[N+1], c[N+1];

    while(1){
        for(i = 1; i <= N; ++i){
            pthread_create(&p[i], NULL, (void *)Producer, (int *)&i);
            pthread_create(&c[i], NULL, (void *)Consumer, (int *)&i);
        }

        for(i = 1; i <= N; ++i){
            pthread_join(p[i], NULL);
            pthread_join(c[i], NULL);
        }
    }

    return 0;
}