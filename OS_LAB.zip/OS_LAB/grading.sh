#!/bin/bash

echo "Enter your marks :"
read marks

if [[ $marks -ge 0 && $marks -le 34 ]]
then
	echo "Fail"
	
elif [[ $marks -ge 35 && $marks -le 55 ]]
then  
	echo "Pass"
	
elif [[ $marks -ge 56 && $marks -le 65 ]]
then  
	echo "First class"
		
else
	echo "Distinction"
	
fi
