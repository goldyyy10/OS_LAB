#!/bin/bash

for i in {0..3}
do
	for j in {0..i}
	do
		echo -n $j
	done
	
	echo

done 
