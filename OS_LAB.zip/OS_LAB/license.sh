#!/bin/bash

echo "Enter your age :"
read age

if [ $age -ge 18 ]
then
	echo "Elegible for driving license"

else

	echo "Not eligible for driving license"	

fi
		
